len([],0).
len([_|T],X):-
    len(T,X1),
    X is X1+1.

evenlist(List):-
    len(List,X),
    X mod 2 =:= 0.

oddlist(List):-
    len(List,X),
    X mod 2 =:= 1.
