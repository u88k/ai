sum(A,B,X):-
    X is A+B.
