multi(A,B,X):-
    X is A*B.

multiply :-
    write("Enter the first number: "),
    read(X),
    write("Enter the second number: "),
    read(Y),
    write("Result = "),
    multi(X,Y,Z),
    write(Z).

