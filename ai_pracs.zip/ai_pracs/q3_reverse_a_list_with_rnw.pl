list_reverse([],[]).
list_reverse([H|T],R):-
    list_reverse(T,L2),
    concat(L2,[H],R).

concat([],L,L).
concat([H|T],L2,[H|L3]):-
    concat(T,L2,L3).

reverse :-
    write("Enter the list: "),
    read(X),
    list_reverse(X,R),
    write("Reversed List: "),
    write(R).

