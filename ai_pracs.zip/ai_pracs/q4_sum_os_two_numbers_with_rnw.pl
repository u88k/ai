sum :-
    write("Enter first num: "),
    read(X),
    write("Enter second num: "),
    read(Y),
    compute(X,Y,R),
    write("Result = "),
    write(R).

compute(A,B,R):-
    R is A+B.
