sum_list([],0).
sum_list([X],X).
sum_list([H|T],S):-
    sum_list(T,S1),
    S is H+S1.
