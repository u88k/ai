male(dadu).
male(papa).
male(sourabh).

female(thakurmaa).
female(maa).
female(sushmita).
female(binita).

husband(dadu, tharkurmaa).
husband(papa, maa).

parent(dadu, papa).
parent(thakurmaa, papa).
parent(papa, sourabh).
parent(papa, sushmita).
parent(papa, binita).
parent(maa, sourabh).
parent(maa, sushmita).
parent(maa, binita).

married(X,Y):-
    female(X),
    male(Y),
    husband(Y,X)|
    male(X),
    female(Y),
    husband(X,Y).

father(A,B):-
    male(A),
    parent(A,B).

mother(A,B):-
    female(A),
    parent(A,B).


son(A,B):-
    male(A),
    parent(B,A).

daughter(A,B):-
    female(A),
    parent(B,A).

grandparent(A,B):-
    parent(A,C),
    parent(C,B).

grandfather(A,B):-
    male(A),
    grandparent(A,B).

grandmother(A,B):-
    female(A),
    grandparent(A,B).

grandchild(A,B):-
    grandparent(B,A).

grandson(A,B):-
    male(A),
    grandparent(B,A).

granddaughter(A,B):-
    female(A),
    grandparent(B,A).


wife(A,B):-
    female(A),
    husband(B,A).

sibling(A,B):-
    parent(X,A),
    parent(X,B).

brother(A,B):-
    male(A),
    sibling(A,B).

sister(A,B):-
    female(A),
    sibling(A,B).

ancestor(A,B):-
    parent(A,B)|
    grandparent(A,B)|
    parent(A,C),
    ancestor(C,B).

descendant(A,B):-
    ancestor(B,A).












