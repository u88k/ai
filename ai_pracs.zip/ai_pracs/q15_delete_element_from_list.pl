% Base case: Deleting the first element
delete(1, [_|T], T).

% Recursive case: Traverse until the Nth element is found
delete(N, [H|T], [H|R]) :-
    N > 1,
    N1 is N - 1,
    delete(N1, T, R).
