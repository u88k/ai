% Base case: Deleting the first element
delete(1, [_|T], T).

% Recursive case: Traverse until the Nth element is found
delete(N, [H|T], [H|R]) :-
    N > 1,
    N1 is N - 1,
    delete(N1, T, R).

% Predicate to delete an element at position N from a list
delete_elem :-
    write("Enter the position you want to delete the element from: "),
    read(N),
    write("Enter the list: "),
    read(L),
    delete(N, L, X),
    write("Updated List = "), write(X), nl.
