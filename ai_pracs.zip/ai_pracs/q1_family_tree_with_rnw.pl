male(dadu).
male(papa).
male(sourabh).

female(thakurmaa).
female(maa).
female(sushmita).
female(binita).

husband(dadu, tharkurmaa).
husband(papa, maa).

parent(dadu, papa).
parent(thakurmaa, papa).
parent(papa, sourabh).
parent(papa, sushmita).
parent(papa, binita).
parent(maa, sourabh).
parent(maa, sushmita).
parent(maa, binita).

married :-
    write("Enter name of the first person: "),
    read(X),
    write("Enter name of the second person: "),
    read(Y),
    female(X),
    male(Y),
    husband(Y,X)|
    male(X),
    female(Y),
    husband(X,Y).

father :-
    write("Enter name of the first person: "),
    read(A),
    write("Enter name of the second person: "),
    read(B),
    male(A),
    parent(A,B).

mother :-
    write("Enter name of the first person: "),
    read(A),
    write("Enter name of the second person: "),
    read(B),
    female(A),
    parent(A,B).


son :-
    write("Enter name of the first person: "),
    read(A),
    write("Enter name of the second person: "),
    read(B),
    male(A),
    parent(B,A).

daughter :-
    write("Enter name of the first person: "),
    read(A),
    write("Enter name of the second person: "),
    read(B),
    female(A),
    parent(B,A).

grandparent :-
    write("Enter name of the first person: "),
    read(A),
    write("Enter name of the second person: "),
    read(B),
    parent(A,C),
    parent(C,B).

grandfather :-
    write("Enter name of the first person: "),
    read(A),
    write("Enter name of the second person: "),
    read(B),
    male(A),
    grandparent(A,B).

grandmother :-
    write("Enter name of the first person: "),
    read(A),
    write("Enter name of the second person: "),
    read(B),
    female(A),
    grandparent(A,B).

grandchild :-
    write("Enter name of the first person: "),
    read(A),
    write("Enter name of the second person: "),
    read(B),
    grandparent(B,A).

grandson :-
    write("Enter name of the first person: "),
    read(A),
    write("Enter name of the second person: "),
    read(B),
    male(A),
    grandparent(B,A).

granddaughter :-
    write("Enter name of the first person: "),
    read(A),
    write("Enter name of the second person: "),
    read(B),
    female(A),
    grandparent(B,A).


wife :-
    write("Enter name of the first person: "),
    read(A),
    write("Enter name of the second person: "),
    read(B),
    female(A),
    husband(B,A).

sibling :-
    write("Enter name of the first person: "),
    read(A),
    write("Enter name of the second person: "),
    read(B),
    parent(X,A),
    parent(X,B).

brother :-
    write("Enter name of the first person: "),
    read(A),
    write("Enter name of the second person: "),
    read(B),
    male(A),
    sibling(A,B).

sister :-
    write("Enter name of the first person: "),
    read(A),
    write("Enter name of the second person: "),
    read(B),
    female(A),
    sibling(A,B).

ancestor :-
    write("Enter name of the first person: "),
    read(A),
    write("Enter name of the second person: "),
    read(B),
    parent(A,B)|
    grandparent(A,B)|
    parent(A,C),
    ancestor(C,B).

descendant :-
    write("Enter name of the first person: "),
    read(A),
    write("Enter name of the second person: "),
    read(B),
    ancestor(B,A).





