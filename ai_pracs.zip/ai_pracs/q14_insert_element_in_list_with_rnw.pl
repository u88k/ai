insert(I,_,[],[I]).
insert(I,1,L,[I|L]).
insert(I,N,[H|T],[H|R]):-
    N>1,
    N1 is N-1,
    insert(I,N1,T,R).

insert_elem :-
    write("Enter the element: "),
    read(I),
    write("Enter the position you want to insert it at: "),
    read(N),
    write("Enter the list: "),
    read(L),
    insert(I,N,L,X),
    write("Updated List = "),
    write(X).
