reverse([],[]).
reverse([H|T],R):-
    reverse(T,L2),
    concat(L2,[H],R).

concat([],L,L).
concat([H|T],L2,[H|L3]):-
    concat(T,L2,L3).
