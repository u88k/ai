% Base case: Appending an empty list to L gives L
append([], L, L).

% Recursive case: Appending [H|T] to L2 results in [H|L3]
append([H|T], L2, [H|L3]) :-
    append(T, L2, L3).

% Main predicate to read two lists and concatenate them
concat :-
    write("Enter list 1: "), nl,
    read(X),
    write("Enter list 2: "), nl,
    read(Y),
    append(X, Y, Z),
    write("Concatenated list: "), write(Z), nl, !.
