memberof(A,[A|_]).
memberof(A,[_|T]):-
    memberof(A,T).

member :-
    write("Enter list: "),
    read(L),
    write("Enter the element: "),
    read(X),
    write("Given element is a member of the given list? = "),
    memberof(X,L).
