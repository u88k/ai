power(_,0,1).
power(Num, Pow, Ans):-
    P1 is Pow-1,
    power(Num,P1,Ans2),
    Ans is Num*Ans2.

exp :-
    write("Enter number: "),
    read(X),
    write("Enter its power: "),
    read(Y),
    write("Result: "),
    power(X,Y,Ans),
    write(Ans).
