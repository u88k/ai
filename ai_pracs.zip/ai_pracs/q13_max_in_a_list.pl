maxnum(A,B,A):- A>=B.
maxnum(A,B,B):- A<B.
max([X],X).
max([H|T],X):-
    max(T,X1),
    maxnum(H,X1,Y),
    X is Y.

