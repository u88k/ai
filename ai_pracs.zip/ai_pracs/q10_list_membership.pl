memberof(A,[A|_]).
memberof(A,[_|T]):-
    memberof(A,T).
