maximum(X,Y,X):-
    X>=Y.
maximum(X,Y,Y):-
    X<Y.

max :-
    write("Enter the first number: "),
    read(X),
    write("Enter the Second number: "),
    read(Y),
    maximum(X,Y,Z),
    write("Max of the two number is "),
    write(Z).


