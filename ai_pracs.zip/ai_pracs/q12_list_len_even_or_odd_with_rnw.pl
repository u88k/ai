% Base case: Length of an empty list is 0
len([], 0).

% Recursive case: Length of a list is 1 + length of the tail
len([_|T], X) :-
    len(T, X1),
    X is X1 + 1.

% Check if the list length is even
evenlist(List) :-
    len(List, X),
    X mod 2 =:= 0.

% Check if the list length is odd
oddlist(List) :-
    len(List, X),
    X mod 2 =:= 1.

% Predicate to read a list and check if it is even or odd
list :-
    write("Enter list: "), nl,
    read(List),
    ( evenlist(List) ->
        write("List is even"), nl
    ;
        write("List is odd"), nl
    ).

